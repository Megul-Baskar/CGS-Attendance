# Cauvery Global School — Smart Attendance Management System

A local Windows-friendly attendance application using Flask, SQLite, HTML, CSS and JavaScript. It does not require Lovable, a cloud account, or a separate SQL server.

## Features in this starter build

- Four ordered login panels: Student, Teacher, Admin, Creator.
- Three preconfigured creator accounts; teacher/admin account creation is available inside Creator Control.
- Passwords are stored as secure hashes using Werkzeug.
- Class/section setup and student creation with school-issued student PIN.
- Individual teacher accounts with assigned classes.
- Teacher attendance marking and correction reason for changed existing records.
- Creator management for classes, students, accounts, academic years, holidays and audit history.
- Admin dashboard is read-only in the app routes; admin does not get attendance write endpoints.
- Student view verifies roll number plus PIN and only shows the verified student's attendance.
- Academic year configuration and attendance summaries.
- Search by name/roll and date, CSV export.
- Optional OCR preview workflow; OCR does not silently save results to the database.
- SQLite database stored locally as `attendance.db`.

## Run on Windows

1. Install Python 3.11+ from https://www.python.org/downloads/ and enable **Add Python to PATH**.
2. Extract this ZIP into a folder you can write to.
3. Double-click `run_windows.bat`. The script creates a virtual environment, installs Flask, and starts the server.
4. Open http://127.0.0.1:5000 in your browser.
5. Open the login page. It contains four access tabs in this order: Student, Teacher, Admin, Creator.
6. The three requested creator accounts are seeded automatically. Sign in as a creator to add classes, students, teacher accounts, and admin accounts.

To stop the server, click its terminal window and press Ctrl+C.

## Role guide

- **Creator:** add classes/sections, students, teachers/admin accounts, academic years, holidays; view audit log; deactivate non-creator accounts; open OCR preview; export records.
- **Class teacher:** can access only assigned classes and mark attendance for those classes.
- **Admin:** read-only overview, search and CSV export.
- **Student:** roll number plus a PIN created by the school creator. Students do not see other students' records.

## OCR setup (optional)

The OCR page is a review-only prototype. To enable image text extraction:
1. Install the Tesseract OCR engine for Windows from a trusted distribution and ensure its executable is on PATH.
2. In the project terminal, activate `.venv` and run `pip install Pillow pytesseract`.
3. Restart the app. Upload a clear image. Check every extracted row manually. OCR results are **not automatically imported**.

The OCR parser is a basic prototype and may not understand complex school-sheet layouts.

## Database and backups

- Database file: `attendance.db` in this folder.
- To back up, stop the app and copy `attendance.db` to a secure backup location.
- The `.flask_secret` file is generated on first run. Keep it private and back it up with the database; changing it logs all browser sessions out.
- Never email or publicly share the database or student PINs.
- Do not use real student data until your school has reviewed privacy, access, backups, and local-device security.

## Current limitations / production checklist

This is a useful local starter, not a formally security-audited school information system. Before deployment beyond a trusted local computer:
- Add CSRF tokens to all state-changing forms and login rate limiting.
- Add pagination and more complete audit trails.
- Review student-data handling with school leadership and guardians as appropriate.
- Test role permissions, edge cases, backup recovery and attendance calculations with synthetic data.
- Configure secure HTTPS, host firewall, account recovery and managed backups if ever deployed on a network.
- OCR needs external Tesseract installation and requires manual review.
- CSV export currently exports attendance rows; the admin UI is read-only.
- Use a strong, unique creator password and do not share it.

## Academic-year logic

The default academic year is seeded as April 1 to March 31, based on the current date. Creator Control can add and activate a different year. Attendance percentage is based on recorded present/absent days within the active year; missing records are not treated as absences. Future dates and dates marked as holidays are excluded from the summary.


## Default creator sign-in

The following three creator accounts are automatically added to a new database:

- Username: `PeaceBreaker_WCO`
- Username: `Dushyan`
- Username: `Vishal`

The initial passwords are the ones provided by the project owner for these accounts. Passwords are stored as hashes in the database, not as readable database values. Change these defaults before using real student records or sharing the application.

The visual theme is black/dark throughout the application.
