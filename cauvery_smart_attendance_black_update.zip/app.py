import os, sqlite3, secrets, csv, io, calendar, re
from datetime import date, datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("ATTENDANCE_DB", os.path.join(APP_DIR, "attendance.db"))
SECRET_PATH = os.path.join(APP_DIR, ".flask_secret")

def get_secret():
    env = os.environ.get("FLASK_SECRET_KEY")
    if env:
        return env
    if os.path.exists(SECRET_PATH):
        with open(SECRET_PATH, "r", encoding="utf-8") as f:
            return f.read().strip()
    value = secrets.token_urlsafe(48)
    with open(SECRET_PATH, "w", encoding="utf-8") as f:
        f.write(value)
    try:
        os.chmod(SECRET_PATH, 0o600)
    except OSError:
        pass
    return value

app = Flask(__name__)
app.secret_key = get_secret()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    return db

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('creator','admin','teacher','student')),
          display_name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          student_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS classes(
          id INTEGER PRIMARY KEY AUTOINCREMENT, class_name TEXT NOT NULL, section TEXT NOT NULL DEFAULT '',
          UNIQUE(class_name, section)
        );
        CREATE TABLE IF NOT EXISTS students(
          id INTEGER PRIMARY KEY AUTOINCREMENT, roll_no TEXT NOT NULL UNIQUE,
          full_name TEXT NOT NULL, class_id INTEGER NOT NULL REFERENCES classes(id),
          pin_hash TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS teacher_assignments(
          user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
          PRIMARY KEY(user_id, class_id)
        );
        CREATE TABLE IF NOT EXISTS academic_years(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
          start_date TEXT NOT NULL, end_date TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS school_calendar(
          id INTEGER PRIMARY KEY AUTOINCREMENT, calendar_date TEXT NOT NULL UNIQUE,
          label TEXT NOT NULL DEFAULT 'Holiday', kind TEXT NOT NULL DEFAULT 'holiday'
        );
        CREATE TABLE IF NOT EXISTS attendance(
          id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id),
          attendance_date TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('present','absent')),
          marked_by INTEGER REFERENCES users(id), updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          correction_reason TEXT NOT NULL DEFAULT '',
          UNIQUE(student_id, attendance_date)
        );
        CREATE TABLE IF NOT EXISTS audit_logs(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER REFERENCES users(id),
          action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date);
        CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
        """)
        # Create a default academic year only; it can be changed in Creator Control.
        if not db.execute("SELECT 1 FROM academic_years LIMIT 1").fetchone():
            today = date.today()
            start_year = today.year if today.month >= 4 else today.year - 1
            db.execute("INSERT INTO academic_years(name,start_date,end_date,active) VALUES(?,?,?,1)",
                       (f"{start_year}-{start_year+1}", f"{start_year}-04-01", f"{start_year+1}-03-31"))
        # Make the newest academic year active if none is active.
        if not db.execute("SELECT 1 FROM academic_years WHERE active=1 LIMIT 1").fetchone():
            row = db.execute("SELECT id FROM academic_years ORDER BY start_date DESC LIMIT 1").fetchone()
            if row: db.execute("UPDATE academic_years SET active=1 WHERE id=?", (row["id"],))

init_db()

# Seed the three requested creator accounts on first launch. Only password hashes
# are stored in the source/database; no first-run setup screen is required.
DEFAULT_CREATORS = [
    ("PeaceBreaker_WCO", "PeaceBreaker_WCO", "pbkdf2:sha256:600000$b0ck3jadOgd5Yto5$1ee3abeb8275b03a4cd36e54f54f10cab721535d3a0d5025501a4c6ef81c7eaf"),
    ("Dushyan", "Dushyan", "pbkdf2:sha256:600000$SmvVEYL8j73GUroh$f2eabef9cfe4ed5497fdfcaaf618f2c65c5156165c7e8cd8d18f6eed61b149fd"),
    ("Vishal", "Vishal", "pbkdf2:sha256:600000$SlzWP9DDuAxDmRsx$b87658635cbb279cb3ad4882220e9eb4837662db25d1011a3a29e62fbf22dc66"),
]
with connect() as db:
    for username, display_name, password_hash in DEFAULT_CREATORS:
        db.execute("INSERT OR IGNORE INTO users(username,password_hash,role,display_name) VALUES(?,?,?,?)",
                   (username, password_hash, "creator", display_name))

def log_action(action, detail=""):
    uid = session.get("user_id")
    with connect() as db:
        db.execute("INSERT INTO audit_logs(user_id,action,detail) VALUES(?,?,?)", (uid, action, str(detail)[:500]))

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        with connect() as db:
            u = db.execute("SELECT * FROM users WHERE id=? AND active=1", (session["user_id"],)).fetchone()
        if not u:
            session.clear()
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def roles(*allowed):
    def decorator(fn):
        @wraps(fn)
        @login_required
        def wrapped(*args, **kwargs):
            if session.get("role") not in allowed:
                abort(403)
            return fn(*args, **kwargs)
        return wrapped
    return decorator

def current_user():
    if not session.get("user_id"): return None
    with connect() as db:
        return db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()

@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "today_iso": date.today().isoformat()}

@app.route("/")
def index():
    if session.get("user_id"):
        role = session.get("role")
        return redirect(url_for({"creator":"creator_dashboard","admin":"admin_dashboard","teacher":"teacher_dashboard"}.get(role,"login")))
    return redirect(url_for("login"))

@app.route("/setup", methods=["GET", "POST"])
def setup():
    # Retain old bookmarks, but no longer offer public account initialization.
    flash("Initial setup is no longer needed. Sign in using one of the access panels.", "info")
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    selected_role = request.args.get("role", "student").lower()
    if selected_role not in ("student", "teacher", "admin", "creator"):
        selected_role = "student"
    if request.method == "POST":
        selected_role = request.form.get("role", selected_role).lower()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with connect() as db:
            u = db.execute("SELECT * FROM users WHERE username=? AND active=1", (username,)).fetchone()
        if u and u["role"] == selected_role and check_password_hash(u["password_hash"], password):
            session.clear()
            session["user_id"] = u["id"]
            session["role"] = u["role"]
            session["username"] = u["username"]
            log_action("login", f"Role={u['role']}")
            return redirect(url_for({"creator":"creator_dashboard","admin":"admin_dashboard","teacher":"teacher_dashboard"}[u["role"]]))
        flash("Invalid username/password for the selected access type.", "error")
    return render_template("login.html", selected_role=selected_role)

@app.route("/student-access", methods=["GET","POST"])
def student_access():
    if request.method == "POST":
        roll = request.form.get("roll_no","").strip()
        pin = request.form.get("pin","")
        with connect() as db:
            st = db.execute("""SELECT s.*, c.class_name, c.section FROM students s
                               JOIN classes c ON c.id=s.class_id WHERE s.roll_no=? AND s.active=1""",(roll,)).fetchone()
        if st and st["pin_hash"] and check_password_hash(st["pin_hash"], pin):
            # Student access is a short-lived verified session limited to their own record.
            session.clear()
            session["student_id"] = st["id"]
            session["role"] = "student_view"
            session["student_roll"] = st["roll_no"]
            log_action("student_verified_view", f"roll={st['roll_no']}")
            return redirect(url_for("student_public_dashboard"))
        flash("Could not verify that roll number and student PIN. Ask the school creator for access.", "error")
    return render_template("student_access.html")

@app.route("/student-view")
def student_public_dashboard():
    if session.get("role") != "student_view" or not session.get("student_id"):
        return redirect(url_for("student_access"))
    sid = session["student_id"]
    with connect() as db:
        st = db.execute("""SELECT s.*, c.class_name, c.section FROM students s JOIN classes c ON c.id=s.class_id
                           WHERE s.id=? AND s.active=1""",(sid,)).fetchone()
        if not st:
            session.clear(); return redirect(url_for("student_access"))
        rows = db.execute("SELECT attendance_date,status FROM attendance WHERE student_id=? ORDER BY attendance_date DESC",(sid,)).fetchall()
        active_year = db.execute("SELECT * FROM academic_years WHERE active=1 LIMIT 1").fetchone()
        holidays = db.execute("SELECT calendar_date,label FROM school_calendar WHERE kind='holiday'").fetchall()
    summary = calculate_summary(rows, active_year, holidays)
    return render_template("student_dashboard.html", student=st, records=rows, summary=summary, student_view=True)

@app.route("/logout")
def logout():
    if session.get("user_id"): log_action("logout")
    session.clear()
    return redirect(url_for("index"))

def get_active_year(db):
    return db.execute("SELECT * FROM academic_years WHERE active=1 LIMIT 1").fetchone()

def calculate_summary(records, year, holidays):
    if not year: return {"present":0,"absent":0,"eligible":0,"percentage":0.0}
    today = date.today().isoformat()
    holiday_dates = {h["calendar_date"] for h in holidays}
    present = absent = 0
    for r in records:
        d = r["attendance_date"]
        if year["start_date"] <= d <= min(year["end_date"],today) and d not in holiday_dates:
            if r["status"] == "present": present += 1
            elif r["status"] == "absent": absent += 1
    eligible = present + absent
    return {"present":present,"absent":absent,"eligible":eligible,"percentage":round(present*100/eligible,1) if eligible else 0.0}

def teacher_class_ids(db, uid):
    return [r["class_id"] for r in db.execute("SELECT class_id FROM teacher_assignments WHERE user_id=?",(uid,)).fetchall()]

@app.route("/creator")
@roles("creator")
def creator_dashboard():
    with connect() as db:
        stats = {
            "students": db.execute("SELECT COUNT(*) n FROM students WHERE active=1").fetchone()["n"],
            "classes": db.execute("SELECT COUNT(*) n FROM classes").fetchone()["n"],
            "teachers": db.execute("SELECT COUNT(*) n FROM users WHERE role='teacher' AND active=1").fetchone()["n"],
            "records": db.execute("SELECT COUNT(*) n FROM attendance").fetchone()["n"]
        }
        years = db.execute("SELECT * FROM academic_years ORDER BY start_date DESC").fetchall()
        classes = db.execute("SELECT * FROM classes ORDER BY class_name,section").fetchall()
        users = db.execute("SELECT id,username,role,display_name,active FROM users ORDER BY role,display_name").fetchall()
        logs = db.execute("""SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
                             ORDER BY a.id DESC LIMIT 12""").fetchall()
    return render_template("creator.html", stats=stats, years=years, classes=classes, users=users, logs=logs)

@app.route("/creator/class", methods=["POST"])
@roles("creator")
def add_class():
    name = request.form.get("class_name","").strip()
    section = request.form.get("section","").strip()
    if not name: flash("Class name is required.", "error")
    else:
        try:
            with connect() as db: db.execute("INSERT INTO classes(class_name,section) VALUES(?,?)",(name,section))
            log_action("class_created", f"{name}-{section}")
            flash("Class/section created.", "success")
        except sqlite3.IntegrityError: flash("That class and section already exist.", "error")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/student", methods=["POST"])
@roles("creator")
def add_student():
    name = request.form.get("full_name","").strip()
    roll = request.form.get("roll_no","").strip()
    pin = request.form.get("pin","")
    try: class_id = int(request.form.get("class_id",""))
    except ValueError: class_id = 0
    if not name or not roll or len(pin)<6 or not class_id:
        flash("Enter name, roll, class and a student PIN of at least 6 characters.", "error")
        return redirect(url_for("creator_dashboard"))
    try:
        with connect() as db:
            db.execute("INSERT INTO students(roll_no,full_name,class_id,pin_hash) VALUES(?,?,?,?)",
                       (roll,name,class_id,generate_password_hash(pin)))
        log_action("student_created", f"roll={roll}")
        flash("Student added. Give the PIN to the student privately.", "success")
    except sqlite3.IntegrityError:
        flash("Roll number already exists or class is invalid.", "error")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/user", methods=["POST"])
@roles("creator")
def add_user():
    username = request.form.get("username","").strip()
    display = request.form.get("display_name","").strip()
    password = request.form.get("password","")
    role = request.form.get("role","")
    class_ids = request.form.getlist("class_ids")
    if role not in ("teacher","admin") or not username or not display or len(password)<10:
        flash("Provide a username, display name, valid role and password (at least 10 characters).", "error")
        return redirect(url_for("creator_dashboard"))
    try:
        with connect() as db:
            cur = db.execute("INSERT INTO users(username,password_hash,role,display_name) VALUES(?,?,?,?)",
                             (username,generate_password_hash(password),role,display))
            uid = cur.lastrowid
            if role == "teacher":
                for cid in class_ids:
                    if cid.isdigit():
                        db.execute("INSERT OR IGNORE INTO teacher_assignments(user_id,class_id) VALUES(?,?)",(uid,int(cid)))
        log_action("user_created", f"username={username}; role={role}")
        flash("Account created.", "success")
    except sqlite3.IntegrityError: flash("That username already exists.", "error")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/academic-year", methods=["POST"])
@roles("creator")
def add_academic_year():
    name = request.form.get("name","").strip()
    start = request.form.get("start_date","")
    end = request.form.get("end_date","")
    try:
        sd, ed = date.fromisoformat(start), date.fromisoformat(end)
        if not name or sd > ed: raise ValueError()
        active = 1 if request.form.get("active") == "on" else 0
        with connect() as db:
            if active: db.execute("UPDATE academic_years SET active=0")
            db.execute("INSERT INTO academic_years(name,start_date,end_date,active) VALUES(?,?,?,?)",(name,start,end,active))
        log_action("academic_year_created", name)
        flash("Academic year saved.", "success")
    except (ValueError, sqlite3.IntegrityError):
        flash("Check the year name and date range; the name must be unique.", "error")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/activate-year/<int:year_id>", methods=["POST"])
@roles("creator")
def activate_year(year_id):
    with connect() as db:
        if db.execute("SELECT 1 FROM academic_years WHERE id=?",(year_id,)).fetchone():
            db.execute("UPDATE academic_years SET active=CASE WHEN id=? THEN 1 ELSE 0 END",(year_id,))
            log_action("academic_year_activated", str(year_id))
            flash("Active academic year updated.", "success")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/holiday", methods=["POST"])
@roles("creator")
def add_holiday():
    day = request.form.get("calendar_date","")
    label = request.form.get("label","Holiday").strip() or "Holiday"
    try:
        date.fromisoformat(day)
        with connect() as db: db.execute("INSERT INTO school_calendar(calendar_date,label,kind) VALUES(?,?,'holiday')",(day,label))
        log_action("holiday_added", f"{day}: {label}")
        flash("Holiday added.", "success")
    except (ValueError, sqlite3.IntegrityError):
        flash("Invalid date or a calendar entry already exists for that date.", "error")
    return redirect(url_for("creator_dashboard"))

@app.route("/creator/attendance", methods=["GET","POST"])
@roles("creator","teacher")
def attendance_entry():
    with connect() as db:
        if session["role"] == "creator":
            classes = db.execute("SELECT * FROM classes ORDER BY class_name,section").fetchall()
        else:
            ids = teacher_class_ids(db, session["user_id"])
            classes = db.execute("SELECT * FROM classes WHERE id IN (%s) ORDER BY class_name,section" % (",".join("?"*len(ids)) if ids else "NULL"), ids).fetchall()
        class_id = request.values.get("class_id", type=int)
        if not class_id and classes: class_id = classes[0]["id"]
        allowed = {c["id"] for c in classes}
        if class_id not in allowed:
            class_id = classes[0]["id"] if classes else None
        day = request.values.get("day", date.today().isoformat())
        try: date.fromisoformat(day)
        except ValueError: day = date.today().isoformat()
        students = db.execute("SELECT * FROM students WHERE active=1 AND class_id=? ORDER BY roll_no",(class_id,)).fetchall() if class_id else []
        existing = {r["student_id"]:r for r in db.execute("SELECT * FROM attendance WHERE attendance_date=? AND student_id IN (SELECT id FROM students WHERE class_id=?)",(day,class_id)).fetchall()} if class_id else {}
        holiday = db.execute("SELECT * FROM school_calendar WHERE calendar_date=?",(day,)).fetchone()
    if request.method == "POST":
        if day > date.today().isoformat():
            flash("Attendance cannot be marked for a future date.", "error")
            return redirect(url_for("attendance_entry", class_id=class_id, day=day))
        if holiday:
            flash("This date is marked as a holiday. Remove the holiday entry before marking attendance.", "error")
            return redirect(url_for("attendance_entry", class_id=class_id, day=day))
        changed = 0
        with connect() as db:
            for st in students:
                status = request.form.get(f"status_{st['id']}")
                if status not in ("present","absent"): continue
                reason = request.form.get(f"reason_{st['id']}","").strip()
                old = db.execute("SELECT * FROM attendance WHERE student_id=? AND attendance_date=?",(st["id"],day)).fetchone()
                if old and old["status"] != status and not reason:
                    flash(f"Provide a correction reason for roll {st['roll_no']} before changing an existing record.", "error")
                    return redirect(url_for("attendance_entry", class_id=class_id, day=day))
                db.execute("""INSERT INTO attendance(student_id,attendance_date,status,marked_by,correction_reason,updated_at)
                              VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)
                              ON CONFLICT(student_id,attendance_date) DO UPDATE SET
                              status=excluded.status, marked_by=excluded.marked_by,
                              correction_reason=excluded.correction_reason, updated_at=CURRENT_TIMESTAMP""",
                           (st["id"],day,status,session["user_id"],reason))
                changed += 1
            db.execute("INSERT INTO audit_logs(user_id,action,detail) VALUES(?,?,?)",
                       (session["user_id"],"attendance_saved",f"date={day}; class_id={class_id}; rows={changed}"))
        flash(f"Saved attendance for {changed} student record(s).", "success")
        return redirect(url_for("attendance_entry", class_id=class_id, day=day))
    return render_template("attendance_entry.html", classes=classes, selected_class=class_id, day=day, students=students, existing=existing, holiday=holiday)

@app.route("/teacher")
@roles("teacher")
def teacher_dashboard():
    with connect() as db:
        ids = teacher_class_ids(db, session["user_id"])
        classes = db.execute("SELECT * FROM classes WHERE id IN (%s) ORDER BY class_name,section" % (",".join("?"*len(ids)) if ids else "NULL"), ids).fetchall()
        stats = db.execute("SELECT COUNT(*) n FROM students WHERE active=1 AND class_id IN (%s)" % (",".join("?"*len(ids)) if ids else "NULL"), ids).fetchone()["n"]
    return render_template("teacher.html", classes=classes, student_count=stats)

@app.route("/admin")
@roles("admin")
def admin_dashboard():
    with connect() as db:
        stats = {
            "students": db.execute("SELECT COUNT(*) n FROM students WHERE active=1").fetchone()["n"],
            "classes": db.execute("SELECT COUNT(*) n FROM classes").fetchone()["n"],
            "records": db.execute("SELECT COUNT(*) n FROM attendance").fetchone()["n"]
        }
        classes = db.execute("""SELECT c.id,c.class_name,c.section,COUNT(DISTINCT s.id) student_count,
          SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) present_count,
          SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) absent_count
          FROM classes c LEFT JOIN students s ON s.class_id=c.id AND s.active=1
          LEFT JOIN attendance a ON a.student_id=s.id GROUP BY c.id ORDER BY c.class_name,c.section""").fetchall()
        year = get_active_year(db)
        holidays = db.execute("SELECT * FROM school_calendar ORDER BY calendar_date DESC LIMIT 20").fetchall()
    return render_template("admin.html", stats=stats, classes=classes, year=year, holidays=holidays)

@app.route("/search")
@roles("creator","admin","teacher")
def search():
    q = request.args.get("q","").strip()
    day = request.args.get("day","").strip()
    with connect() as db:
        if session["role"] == "teacher":
            ids = teacher_class_ids(db, session["user_id"])
            scope = " AND s.class_id IN (%s)" % (",".join("?"*len(ids)) if ids else "NULL")
            params = list(ids)
        else:
            scope = ""; params = []
        sql = """SELECT s.roll_no,s.full_name,c.class_name,c.section,a.attendance_date,a.status,a.updated_at
                 FROM students s JOIN classes c ON c.id=s.class_id LEFT JOIN attendance a ON a.student_id=s.id WHERE s.active=1"""
        if q:
            sql += " AND (s.roll_no LIKE ? OR s.full_name LIKE ?)"
            params += [f"%{q}%",f"%{q}%"]
        if day:
            sql += " AND a.attendance_date=?"; params.append(day)
        sql += scope + " ORDER BY c.class_name,c.section,s.roll_no LIMIT 500"
        rows = db.execute(sql, params).fetchall()
    return render_template("search.html", rows=rows, q=q, day=day)

@app.route("/export/attendance.csv")
@roles("creator","admin")
def export_csv():
    with connect() as db:
        rows = db.execute("""SELECT s.roll_no,s.full_name,c.class_name,c.section,a.attendance_date,a.status,a.updated_at
          FROM attendance a JOIN students s ON s.id=a.student_id JOIN classes c ON c.id=s.class_id
          ORDER BY a.attendance_date,s.roll_no""").fetchall()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Roll No","Student Name","Class","Section","Date","Status","Updated At"])
    for r in rows:
        writer.writerow([r["roll_no"],r["full_name"],r["class_name"],r["section"],r["attendance_date"],r["status"],r["updated_at"]])
    data = io.BytesIO(out.getvalue().encode("utf-8-sig"))
    return send_file(data, mimetype="text/csv", as_attachment=True, download_name="attendance_export.csv")

@app.route("/ocr", methods=["GET","POST"])
@roles("creator")
def ocr_import():
    extracted = []
    note = "OCR requires the optional pytesseract package and the Tesseract OCR engine installed on this computer."
    if request.method == "POST":
        upload = request.files.get("sheet")
        if not upload or not upload.filename:
            flash("Choose an image file first.", "error")
        else:
            try:
                from PIL import Image
                import pytesseract
                img = Image.open(upload.stream)
                text = pytesseract.image_to_string(img)
                for line in text.splitlines():
                    parts = re.split(r"[,\t;|]+", line.strip())
                    if len(parts) >= 2 and parts[0].strip():
                        status = parts[-1].strip().lower()
                        if status in ("p","present"): status = "present"
                        elif status in ("a","absent"): status = "absent"
                        else: status = "unknown"
                        extracted.append({"roll":parts[0].strip(),"name":parts[1].strip() if len(parts)>2 else "", "status":status})
                note = "Review the extracted rows carefully. This page does not write OCR results to attendance automatically."
            except Exception as e:
                flash("OCR could not run. Install Pillow, pytesseract, and the Tesseract engine; see README. No records were changed.", "error")
    return render_template("ocr.html", extracted=extracted, note=note)

@app.route("/creator/toggle-user/<int:user_id>", methods=["POST"])
@roles("creator")
def toggle_user(user_id):
    if user_id == session["user_id"]:
        flash("You cannot deactivate your own account.", "error")
    else:
        with connect() as db:
            db.execute("UPDATE users SET active=CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=? AND role!='creator'",(user_id,))
        log_action("user_activation_toggled", str(user_id))
        flash("Account status updated.", "success")
    return redirect(url_for("creator_dashboard"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="Your account does not have permission to access this page."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="The requested page could not be found."), 404

if __name__ == "__main__":
    print("Cauvery Smart Attendance is starting.")
    print("Open http://127.0.0.1:5000 in your browser.")
    print("First run: complete the one-time setup page to create secure creator/admin accounts.")
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
